
import java.awt.Color;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author HP
 */
public class userBlock extends javax.swing.JFrame {


    
    DefaultTableModel model;
     DefaultTableModel model1;
    ArrayList<String> issuedBooks =new ArrayList<String>();
    
     ArrayList<String> adder=new ArrayList<String>() ;
    public userBlock() {
        initComponents();
        getContentPane().setBackground(Color.BLACK);
        model=(DefaultTableModel)jTable1.getModel();
         model1=(DefaultTableModel)jTable2.getModel();  
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 0, 0));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("User Block");

        jButton1.setText("Go Back");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Book Category", "Name", "Author"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jButton2.setText("View Books");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Search a Book");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("Request to issue a book");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Username", "Book ", "Author"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(jTable2);

        jButton5.setText("View Issued Books");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setText("Return a Book");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setText("Help");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(189, 189, 189)
                .addComponent(jButton1)
                .addGap(51, 51, 51))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jButton4))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addComponent(jButton3))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(jButton6))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addComponent(jButton7)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(263, 263, 263)
                .addComponent(jButton2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton5)
                .addGap(81, 81, 81))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jButton1))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(151, 151, 151)
                        .addComponent(jButton3)
                        .addGap(28, 28, 28)
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton6)
                        .addGap(18, 18, 18)
                        .addComponent(jButton7)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton2, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jButton5, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 328, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 328, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(78, 78, 78))))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            // TODO add your handling code here:
            Main obj=new Main();
            obj.setVisible(true);
            dispose();
        }  catch (IOException ex) {
            Logger.getLogger(userBlock.class.getName()).log(Level.SEVERE, null, ex);
        }   
    }//GEN-LAST:event_jButton1ActionPerformed
       
  
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
          File f=new File("UserBook.txt");
        try{
            BufferedReader br=new BufferedReader(new FileReader(f));
            DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
            Object [] lines= br.lines().toArray();
            for(int i=0; i<lines.length;i++){
                String[] row=lines[i].toString().split(" ");
                model.addRow(row);
        }
     }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e.getMessage());
       }
      
         try{
           BufferedReader br=new BufferedReader(new FileReader(f));
           String str;
           while((str=br.readLine())!=null){
               adder.add(str);
               issuedBooks.add(str);
           }
       }
       catch(Exception e){
           JOptionPane.showMessageDialog(null, e.getMessage());
       }
         
    }//GEN-LAST:event_jButton2ActionPerformed
       
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
       SearchBook obj=new SearchBook();
       obj.setVisible(true);
       dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    String usercheck="";   //takes value from    arraylist  in    main.java 
    String data="";
     
    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        if(jTable1.getSelectedRow()!=-1){
        int index=0;
        index=jTable1.getSelectedRow();
        String a=jTable1.getValueAt(index,0)+"";
        if(a.compareTo("reference")==0 || a.compareTo("reference")==0){
                JOptionPane.showMessageDialog(null, "Sorry this book cannot be issued!");    
            }
        
        else if(a.compareTo("newArrival")==0 || a.compareTo("NewArrival")==0){
                JOptionPane.showMessageDialog(null, "This book will be issued after 2 months!");
            }
        
        else{
            
        usercheck=Main.name.get((Main.name.toArray().length)-1);
               
        File f=new File("Issuedbook.txt");
        File fi=new File("IssueRequest2.txt");
        try{
             
            BufferedWriter bw=new BufferedWriter(new FileWriter(f,true));
            BufferedWriter bwr=new BufferedWriter(new FileWriter(fi,true));
            data=jTable1.getValueAt(index, 0)+" "+jTable1.getValueAt(index, 1)+" "+jTable1.getValueAt(index, 2);
            issuedBooks.remove(data);
            bw.write(usercheck+" ");
            bw.write(jTable1.getValueAt(index, 1)+" ");
            bw.write(jTable1.getValueAt(index, 2)+"\n");
            
            bwr.write(usercheck+" ");
            bwr.write(jTable1.getValueAt(index, 1)+" ");
            bwr.write(jTable1.getValueAt(index, 2)+"\n");
            File f1=new File("UserBook.txt"); 
            BufferedWriter bw1=new BufferedWriter(new FileWriter(f1,false));
            for(int i=0;i<issuedBooks.size();i++){
                bw1.write(issuedBooks.get(i)+"\n");
            }
            bw1.close();
            

      
            model.removeRow(jTable1.getSelectedRow());
            bwr.close();
            bw.close();
         
             JOptionPane.showMessageDialog(null, "Request sent successfully!");
             
         }
        
        catch(Exception e){
            JOptionPane.showMessageDialog(null,e.getMessage());
        }  
      }
        }
        else
            JOptionPane.showMessageDialog(null, "Pls select a book.");
      
    }//GEN-LAST:event_jButton4ActionPerformed
      ArrayList<String> remove=new ArrayList<String>();
    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
          
        File f=new File("AccepIssReq.txt");
        try{
            BufferedReader br=new BufferedReader(new FileReader(f));
            DefaultTableModel model = (DefaultTableModel)jTable2.getModel();
            Object [] lines= br.lines().toArray();
            for(int i=0; i<lines.length;i++){
                String[] row=lines[i].toString().split(" ");
                model.addRow(row);
        }
           BufferedReader br1=new BufferedReader(new FileReader(f));
           String str;
           while((str=br1.readLine())!=null){
               
               remove.add(str);
           }
     }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e.getMessage());
       }
        
    }//GEN-LAST:event_jButton5ActionPerformed
    String fresh;
    String compare;
    String temp;
    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        if(jTable2.getSelectedRow()!=-1){
        int index=jTable2.getSelectedRow();
        compare=jTable2.getValueAt(index,0)+"";
        usercheck=Main.name.get((Main.name.toArray().length)-1);
        
        if(compare.compareTo(usercheck)!=0){
            JOptionPane.showMessageDialog(null, "You cannot return this book!");
        }
        else{

            fresh="fresh "+jTable2.getValueAt(index, 1)+" "+jTable2.getValueAt(index, 2);
            temp=jTable2.getValueAt(index, 0)+" "+jTable2.getValueAt(index, 1)+" "+jTable2.getValueAt(index, 2);
             
            remove.remove(temp);
            
            adder.add(fresh); 
           
             File f1=new File("AccepIssReq.txt");
             try{
                 
                 BufferedWriter bw=new BufferedWriter (new FileWriter(f1,false));
                 for(int i=0;i<remove.size();i++){
                     bw.write(remove.get(i)+"\n");
                 }
                 bw.close();
                 
             }catch(Exception e){
                 JOptionPane.showMessageDialog(null,e.getMessage());
             }
            File f=new File("UserBook.txt");
            try{
                BufferedWriter bw1=new BufferedWriter(new FileWriter(f,false));
                for(int i=0;i<adder.size();i++){
                    bw1.write(adder.get(i)+"\n");
                }
                bw1.close();
                
            }catch(Exception e){
                JOptionPane.showMessageDialog(null, e.getMessage());
            }
            
              model1.removeRow(jTable2.getSelectedRow());
            JOptionPane.showMessageDialog(null, "Book returned successfully.");
        }
        }
        else
            JOptionPane.showMessageDialog(null, "Pls Selecet a book.");

    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        JOptionPane.showMessageDialog(null, "1. If you want to search a book then click Search button\n"
                                          + "2. If you want to request for issuing book then click on book and press issue button\n"
                                          + "3. If you want to return a book then click on your name in table and press return button\n"
                                          + "4. Click view books button to view the books ");
    }//GEN-LAST:event_jButton7ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(userBlock.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(userBlock.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(userBlock.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(userBlock.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new userBlock().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    // End of variables declaration//GEN-END:variables
}
